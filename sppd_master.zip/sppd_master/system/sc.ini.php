<?php
	die("Sapeltu Inc.") ; 
?> 
######################
#ip 		= server
#user 		= user database
#password 	= password database
#database 	= name database
#jh 		= setting session laen
#SYS_		= server dkk
######################
ip 			= localhost
user 		= root
password 	= 
database 	= sppd
SYS_Log		= db